const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Role_type = new Schema({
    role_id:{type: String},   
    role_name:{type: String},
    role_status:{type: Number},
},{
    collection: 'role_type'
});
module.exports = mongoose.model('Role_type', Role_type);
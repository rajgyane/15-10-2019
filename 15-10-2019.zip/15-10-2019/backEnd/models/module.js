const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Module = new Schema({
    module_id:{type:String},
    module_name:{type: String},
    module_status:{type: String},
    routing_url:{type: String},
    mat_icon:{type: String},
},{
    collection: 'module'
});
module.exports = mongoose.model('Module', Module);
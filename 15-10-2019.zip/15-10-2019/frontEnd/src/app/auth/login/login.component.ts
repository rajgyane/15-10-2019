import { Component, OnInit } from '@angular/core';
import {trigger,state,style,animate,transition} from '@angular/animations';
import {FormGroup,  FormBuilder,  Validators} from '@angular/forms';
import { ServicesService} from '../services.service';
import{Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  angForm: FormGroup;
  loginstatus:any;
  errormsg:string;
  sucussmsg:string;
  showSpinner=false;
  logindata={};
  permissiondata:any=[];
  
  constructor(private fb: FormBuilder,private ls:ServicesService,private route:Router) {this.createForm(); }
  createForm() {
    this.angForm = this.fb.group({
      email: ['', Validators.required ],
      password: ['', Validators.required ]
    });
  }

  ngOnInit() {
    this.ls.logout();
  }
  login(email,password)
  {
    this.showSpinner=true;
    this.ls.login(email,password).subscribe((data: any) => {
      this.loginstatus = data;
      this.permissiondata=data['permissiondata'];
      
      console.log(this.permissiondata);
      if(this.loginstatus['message']=='Succuss')
      {
        localStorage.setItem('token',this.loginstatus['token']);
        localStorage.setItem('user_type',this.loginstatus['usertype']);
        localStorage.setItem('assign_role',this.loginstatus['assign_role']);
        localStorage.setItem('org_id',this.loginstatus['org_id']);
        localStorage.setItem('permission_data',data['permissiondata']);
        this.showSpinner=false;
        this.sucussmsg="Login Successfull ";
        setTimeout(() => 
        {
          this.sucussmsg='';
          this.route.navigate(["/admin"]);

        },2000);
        
      }else{
        this.errormsg=this.loginstatus['message'];
        this.showSpinner=false;
        setTimeout(() => 
        {
                 this.errormsg='';
        },2000);
        
      }  
    })
    
    
  
    
  }

}

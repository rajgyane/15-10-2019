import { Component, OnInit,ViewChild } from '@angular/core';
import {LeadSource} from '../../model/lead-source';
import {ServicesService} from '../../auth/services.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { EditleadsourcelistComponent } from '../editleadsourcelist/editleadsourcelist.component';
import { DeletestatusdataComponent} from '../deletestatusdata/deletestatusdata.component';
import { AddleadsourceComponent} from '../addleadsource/addleadsource.component';

@Component({
  selector: 'app-leadsourcelist',
  templateUrl: './lead-source-list.component.html',
  styleUrls: ['./lead-source-list.component.css']
})
export class LeadsourcelistComponent implements OnInit {

  
leadsourcestatus_data:LeadSource[]=[];
dataSource: MatTableDataSource<LeadSource>;
show = true;
delstatus:string;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;

displayedColumns: string[] = ['Srno','lead_source_name','actions'];

role_type:string;
  constructor(private ls:ServicesService,public dialog: MatDialog) { }

  ngOnInit() {
    this.role_type=localStorage.getItem('assign_role');
  this.gwtLeadSourceData();
         
  }

gwtLeadSourceData(){
  this.ls
      .getLeadsourcedata()
      .subscribe((data: LeadSource[]) => {
        this.leadsourcestatus_data = data;
        
        this.dataSource = new MatTableDataSource(this.leadsourcestatus_data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.show = false;
              });

}



  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
 edit_leadsource(v)
    {
      //console.log(v);
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='400px';
      
      dialogConfig1.data={id: v};

      const dialogRef = this.dialog.open(EditleadsourcelistComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
     
    }
    delete_leadsource(delid)
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='400px';
      dialogConfig1.height='250px';
      
      dialogConfig1.data={msg1:'Confirm',msg:'Do you want to delete !!',status:1};

      const dialogRef = this.dialog.open(DeletestatusdataComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        if(result==true)
        {
          this.ls
      .deleteleadsourcedata(delid)
      .subscribe((data: any) => {
        this.delstatus = data;
        dialogConfig1.data={msg1:'Succuss',msg:'Your Data Deleted Successfully !!',status:0};
          const dialogRef = this.dialog.open(DeletestatusdataComponent,dialogConfig1);
          this.gwtLeadSourceData();
              });
          
        }
        });
    }
    add_lead_source()
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='400px';
      
      //dialogConfig1.data={id: v};

      const dialogRef = this.dialog.open(AddleadsourceComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });

    }
  


}


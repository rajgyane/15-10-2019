import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import {LeadAddComponent} from './lead-add/lead-add.component';
import {LeadGetComponent} from './lead-get/lead-get.component';
import {LeadEditComponent} from './lead-edit/lead-edit.component';
import { ViewfollowupsComponent} from './viewfollowups/viewfollowups.component';
import {FollowupsComponent} from './followups/followups.component';
import {AddOrganizationComponent} from './add-organization/add-organization.component';
import {ListOrgComponent} from './list-org/list-org.component';
import {EditOrgComponent} from './edit-org/edit-org.component';
import {UserListComponent} from './user-list/user-list.component';
import {PermissionComponent} from './permission/permission.component';
import {LeadsourcelistComponent} from './lead-source-list/lead-source-list.component';
import {FollowupStatusListComponent} from './followup-status-list/followup-status-list.component';

import { AuthGuard } from '../auth/auth.guard';


const routes: Routes = [
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthGuard],
    
    children: [
      {
      path: '',
      children: [
        
        { path: '', component: AdminDashboardComponent },
        { path: 'create', component: LeadAddComponent },
        { path: 'lead', component: LeadGetComponent },
        {path:'edit/:id',component:LeadEditComponent},
        {path:'viewfollowup/:id',component:ViewfollowupsComponent},
        {path:'followup/:id',component:FollowupsComponent},
        {path:'add_organization',component:AddOrganizationComponent},
        {path:'list_org',component:ListOrgComponent},
        {path:'edit_org/:id',component:EditOrgComponent},
        {path:'user_list',component:UserListComponent},
        {path:'permission',component:PermissionComponent},
        {path:'lead_source_list',component:LeadsourcelistComponent},
        {path:'followup_status_list',component:FollowupStatusListComponent}
      ],
    }
  ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

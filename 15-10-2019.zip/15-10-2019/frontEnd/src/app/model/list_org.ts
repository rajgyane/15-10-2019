export class List_org {
    full_name_org:string;
    org_aliase:string;
    logo:string;
    address:string;
    status:string;
}


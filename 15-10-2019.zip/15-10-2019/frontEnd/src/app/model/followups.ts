export default class Followups {
   
    ref:string;   
    status: String;
    followup: String;
    datetime: String;
    nextstep: String;
    expectedwalikin: String;
  }